import __init__ as ev

ev.prnt('8v.1.1.6v.out"It\ works!"fin')
